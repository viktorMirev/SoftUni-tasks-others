﻿public class Assassin : AbstractHero
{
    public Assassin(string name) : base(name, 25, 100, 15, 150, 300)
    {
    }
}

