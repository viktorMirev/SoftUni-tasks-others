﻿public class Barbarian : AbstractHero
{
    public Barbarian(string name) : base(name, 90, 25, 10, 350, 150)
    {
    }
}

