﻿namespace RecyclingStation.Logic.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
