﻿namespace OOPEx
{
    class Car
    {
        public string Model { get; set; }
        public string Speed { get; set; }


        public Car(string n, string e)
        {
            this.Model = n;
            this.Speed = e;

        }
    }
}
