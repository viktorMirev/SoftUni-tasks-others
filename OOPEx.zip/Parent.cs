﻿namespace OOPEx
{
    class Parent
    {
        public string Name { get; set; }
        public string Birthday { get; set; }


        public Parent(string n, string e)
        {
            this.Name = n;
            this.Birthday = e;

        }
    }
}
