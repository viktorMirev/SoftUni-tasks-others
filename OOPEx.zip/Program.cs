﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OOPEx
{
    class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine();
            var people = new Dictionary<string, Person>();

            while (input != "End")
            {
                var data = input.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                var name = data[0];

                if (!people.ContainsKey(name))
                {
                    people.Add(name, new Person(name));
                }

                var opp = data[1];

                switch (opp)
                {
                    case "car":
                        var mod = data[2];
                        var sp = data[3];
                        people[name].myCar = new Car(mod, sp);
                        break;

                    case "company":
                        var cName = data[2];
                        var dep = data[3];
                        var salary = double.Parse(data[4]);
                        people[name].myCompany = new Company(cName, dep, salary);
                        break;

                    case "pokemon":
                        var pName = data[2];
                        var pType = data[3];
                        people[name].myPokes.Add(new Pokemon(pName, pType));
                        break;

                    case "parents":
                        var parName = data[2];
                        var birthday = data[3];
                        people[name].myParents.Add(new Parent(parName,birthday));
                        break;

                    case "children":
                        var chName = data[2];
                        var chBirthday = data[3];
                        people[name].myChildren.Add(new Child(chName, chBirthday));
                        break;

                }

                input = Console.ReadLine();
            }

            var person = people[Console.ReadLine()];

            Console.WriteLine(person.Name);
            Console.WriteLine("Company:");
            if (person.myCompany != null)
            {
                Console.WriteLine($"{person.myCompany.Name} {person.myCompany.Department} {person.myCompany.Salary:f2}");
            }
            Console.WriteLine("Car:");
            if (person.myCar != null)
            {
                Console.WriteLine($"{person.myCar.Model} {person.myCar.Speed}");

            }
            Console.WriteLine("Pokemon:");
            foreach (var pok in person.myPokes)
            {
                Console.WriteLine($"{pok.Name} {pok.Type}");
            }
            Console.WriteLine("Parents:");
            foreach (var par in person.myParents)
            {
                Console.WriteLine($"{par.Name} {par.Birthday}");
            }

            Console.WriteLine("Children:");
            foreach (var ch in person.myChildren)
            {
                Console.WriteLine($"{ch.Name} {ch.Birthday}");
            }



        }


    }
}