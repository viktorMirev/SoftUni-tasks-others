﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPEx
{
    class Person
    {
        public string Name { get; set; }
        public Car myCar { get; set; }
        public Company myCompany { get; set; }
        public List<Pokemon> myPokes { get; set; }
        public List<Parent> myParents { get; set; }
        public List<Child> myChildren { get; set; }

        public Person (string name)
        {
            this.Name = name;
            myPokes = new List<Pokemon>();
            myParents = new List<Parent>();
            myChildren = new List<Child>();
        }

        public Person (string name,Car car)
            :this(name)
        {
            this.myCar = car;
        }

        public Person(string name, Company comp)
           : this(name)
        {
            this.myCompany = comp;
        }

       

    }
}
