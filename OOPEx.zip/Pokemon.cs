﻿namespace OOPEx
{
    class Pokemon
    {
       public string Name { get; set; }
        public string Type { get; set; }
      

        public Pokemon(string n, string e)
        {
            this.Name = n;
            this.Type = e;
           
        }
    }
}
