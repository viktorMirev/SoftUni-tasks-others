﻿namespace OOPEx
{
    class Company
    {
        public string Name { get; set; }
        public string Department { get; set; }
        public double Salary { get; set; }


        public Company(string n, string e, double S)
        {
            this.Name = n;
            this.Department = e;
            this.Salary = S;

        }
    }
}
