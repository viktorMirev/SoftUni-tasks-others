﻿namespace OOPEx
{
    class Child
    {
        public string Name { get; set; }
        public string Birthday { get; set; }


        public Child(string n, string e)
        {
            this.Name = n;
            this.Birthday = e;

        }
    }
}
